NEBULA ALARM - Android project
================================
Nama aplikasi: NEBULA ALARM
Application ID: com.nebula.alarm

Build:
1. Upload seluruh isi ZIP ke repository GitHub.
2. Simpan workflow build.yml di .github/workflows/build.yml.
3. Buka tab Actions dan jalankan "Build NEBULA ALARM APK".
4. Unduh artifact NEBULA-ALARM-APK.

Fitur awal:
- Jam analog dan UI futuristik dari prototype HTML.
- Banyak alarm, pengulangan hari, aktif/nonaktif, hapus alarm.
- Android AlarmManager exact alarm + notifikasi layar alarm; pengulangan mingguan dijadwalkan ulang otomatis.
- Snooze 5 menit.
- Pilih file audio dari penyimpanan HP untuk nada alarm.
- Ikon PNG transparan mengikuti siluet gambar sumber.

Catatan:
- Android dapat meminta izin notifikasi dan alarm tepat saat pertama dibuka.
- Mode hemat baterai/vendor dapat membatasi alarm; izinkan aplikasi berjalan tanpa pembatasan baterai untuk keandalan terbaik.
- AlarmManager Android native digunakan; pengujian akhir tetap perlu dilakukan pada perangkat target.
