package com.nebula.alarm;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class AlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String id = intent.getStringExtra("id");
        String time = intent.getStringExtra("time");
        String days = intent.getStringExtra("days");
        String name = intent.getStringExtra("name");
        String sound = intent.getStringExtra("sound");
        if (days != null && time != null && !time.equals("SNOOZE")) {
            AlarmScheduler.schedule(context, id, time, days, intent.getStringExtra("name"), intent.getStringExtra("sound"), 0L);
        }
        Intent full = new Intent(context, AlarmActivity.class);
        full.putExtras(intent);
        full.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent fullPi = PendingIntent.getActivity(context, (id == null ? 1 : id.hashCode()), full,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        NotificationManager nm = (NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        String channel = "nebula_alarm_channel";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(channel, "Alarm NEBULA", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Notifikasi alarm dan layar alarm penuh");
            ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            nm.createNotificationChannel(ch);
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ?
                new Notification.Builder(context, channel) : new Notification.Builder(context);
        b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
         .setContentTitle(name == null ? "NEBULA ALARM" : name)
         .setContentText("Alarm " + (time == null ? "" : time) + " sedang berbunyi")
         .setCategory(Notification.CATEGORY_ALARM)
         .setPriority(Notification.PRIORITY_MAX)
         .setAutoCancel(true)
         .setFullScreenIntent(fullPi, true)
         .setContentIntent(fullPi);
        try { nm.notify(id == null ? 1001 : id.hashCode(), b.build()); } catch (SecurityException ignored) {}
        try { context.startActivity(full); } catch (Exception ignored) {}
    }
}
