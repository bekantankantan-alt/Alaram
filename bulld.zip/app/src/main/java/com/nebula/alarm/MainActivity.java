package com.nebula.alarm;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.database.Cursor;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.util.Calendar;

public class MainActivity extends Activity {
    private WebView web;
    private static final int PICK_AUDIO = 4102;
    private static final int REQ_NOTIF = 4103;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFF020D18);
        getWindow().setNavigationBarColor(0xFF020D18);
        web = new WebView(this);
        web.setBackgroundColor(0xFF020D18);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setMediaPlaybackRequiresUserGesture(false);
        web.addJavascriptInterface(new AlarmBridge(this), "NativeBridge");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        requestRuntimePermissions();
        requestExactAlarmPermission();
    }

    private void requestRuntimePermissions() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
        }
    }
    private void requestExactAlarmPermission() {
        if (Build.VERSION.SDK_INT >= 31) {
            AlarmManager am = (AlarmManager)getSystemService(ALARM_SERVICE);
            if (!am.canScheduleExactAlarms()) {
                try { startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)); }
                catch (Exception ignored) {}
            }
        }
    }

    public class AlarmBridge {
        private final Context ctx;
        AlarmBridge(Context c) { ctx = c; }

        @JavascriptInterface public void scheduleAlarm(String id, String time, String days, String name, String soundUri) {
            AlarmScheduler.schedule(ctx, id, time, days, name, soundUri, 0L);
        }
        @JavascriptInterface public void cancelAlarm(String id) { AlarmScheduler.cancel(ctx, id); }
        @JavascriptInterface public void pickSong() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("audio/*");
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                startActivityForResult(i, PICK_AUDIO);
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_AUDIO && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
            catch (Exception ignored) {}
            String title = "Lagu pilihan";
            Cursor c = getContentResolver().query(uri, null, null, null, null);
            if (c != null) {
                try { int ix = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (c.moveToFirst() && ix >= 0) title = c.getString(ix); }
                finally { c.close(); }
            }
            String js = "window.onNativeSongSelected(" + org.json.JSONObject.quote(uri.toString()) + "," +
                    org.json.JSONObject.quote(title) + ")";
            web.evaluateJavascript(js, null);
        }
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
