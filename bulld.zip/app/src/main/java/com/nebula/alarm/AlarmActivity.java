package com.nebula.alarm;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class AlarmActivity extends Activity {
    private MediaPlayer player;
    private String id, time, name, sound;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true); setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
        id = getIntent().getStringExtra("id");
        time = getIntent().getStringExtra("time");
        name = getIntent().getStringExtra("name");
        sound = getIntent().getStringExtra("sound");
        buildScreen();
        playSound();
    }

    private void buildScreen() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(28, 28, 28, 28);
        box.setBackgroundColor(0xFF031321);
        TextView title = new TextView(this);
        title.setText("NEBULA ALARM");
        title.setTextColor(0xFF5CEBFF);
        title.setTextSize(18);
        TextView clock = new TextView(this);
        clock.setText(time == null ? "ALARM" : time);
        clock.setTextColor(0xFFFFFFFF);
        clock.setTextSize(56);
        TextView label = new TextView(this);
        label.setText(name == null ? "Waktunya bangun!" : name);
        label.setTextColor(0xFFB8EFFF);
        label.setTextSize(18);
        Button snooze = new Button(this); snooze.setText("TUNDA 5 MENIT");
        Button stop = new Button(this); stop.setText("MATIKAN ALARM");
        box.addView(title); box.addView(clock); box.addView(label); box.addView(snooze); box.addView(stop);
        setContentView(box);
        snooze.setOnClickListener(v -> { stopSound(); scheduleSnooze(); finish(); });
        stop.setOnClickListener(v -> { stopSound(); finish(); });
    }

    private void playSound() {
        try {
            Uri uri = (sound != null && !sound.isEmpty()) ? Uri.parse(sound) : RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (uri == null) uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            player.setDataSource(this, uri);
            player.setLooping(true);
            player.prepare();
            player.start();
        } catch (Exception e) {
            try {
                Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
                player = MediaPlayer.create(this, uri);
                if (player != null) { player.setLooping(true); player.start(); }
            } catch (Exception ignored) {}
        }
    }

    private void stopSound() { try { if (player != null) { player.stop(); player.release(); player = null; } } catch (Exception ignored) {} }

    private void scheduleSnooze() {
        Intent i = new Intent(this, AlarmReceiver.class);
        i.putExtra("id", "snooze-" + System.currentTimeMillis());
        i.putExtra("time", "SNOOZE"); i.putExtra("name", name); i.putExtra("sound", sound);
        PendingIntent pi = PendingIntent.getBroadcast(this, (int)System.currentTimeMillis(),
                i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am = (AlarmManager)getSystemService(Context.ALARM_SERVICE);
        long at = System.currentTimeMillis() + 5 * 60 * 1000L;
        if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        else am.setExact(AlarmManager.RTC_WAKEUP, at, pi);
    }

    @Override protected void onDestroy() { stopSound(); super.onDestroy(); }
}
