package com.nebula.alarm;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.util.Calendar;

public class AlarmScheduler {
    static PendingIntent pending(Context c, String id, String time, String days, String name, String sound) {
        Intent i = new Intent(c, AlarmReceiver.class);
        i.putExtra("id", id); i.putExtra("time", time); i.putExtra("days", days); i.putExtra("name", name); i.putExtra("sound", sound);
        return PendingIntent.getBroadcast(c, id.hashCode(), i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    public static void schedule(Context c, String id, String time, String days, String name, String sound, long delayMs) {
        try {
            String[] hm = time.split(":");
            int hour = Integer.parseInt(hm[0]), minute = Integer.parseInt(hm[1]);
            String[] ds = days.split(",");
            Calendar now = Calendar.getInstance(), next = null;
            if (delayMs > 0) {
                next = (Calendar)now.clone(); next.setTimeInMillis(now.getTimeInMillis() + delayMs);
            } else {
                for (String day : ds) {
                    int jsDay = Integer.parseInt(day.trim());
                    int wanted = jsDay + 1; // Java Calendar: Sunday=1, JS Date: Sunday=0
                    Calendar candidate = (Calendar)now.clone();
                    candidate.set(Calendar.HOUR_OF_DAY, hour);
                    candidate.set(Calendar.MINUTE, minute);
                    candidate.set(Calendar.SECOND, 0);
                    candidate.set(Calendar.MILLISECOND, 0);
                    int add = (wanted - candidate.get(Calendar.DAY_OF_WEEK) + 7) % 7;
                    candidate.add(Calendar.DAY_OF_YEAR, add);
                    if (!candidate.after(now)) candidate.add(Calendar.DAY_OF_YEAR, 7);
                    if (next == null || candidate.before(next)) next = candidate;
                }
            }
            if (next == null) return;
            PendingIntent pi = pending(c, id, time, days, name, sound);
            AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
            if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), pi);
            else am.setExact(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), pi);
        } catch (Exception ignored) {}
    }

    public static void cancel(Context c, String id) {
        Intent i = new Intent(c, AlarmReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(c, id.hashCode(), i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        am.cancel(pi); pi.cancel();
    }
}
